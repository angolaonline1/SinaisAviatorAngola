import { pgTable, text, serial, integer, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const predictions = pgTable("predictions", {
  id: serial("id").primaryKey(),
  multiplier: decimal("multiplier", { precision: 6, scale: 2 }).notNull(),
  confidence: integer("confidence").notNull(),
  hash: text("hash").notNull(),
  status: text("status", { enum: ["pending", "win", "loss"] }).notNull().default("pending"),
  actualMultiplier: decimal("actual_multiplier", { precision: 6, scale: 2 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

export const statistics = pgTable("statistics", {
  id: serial("id").primaryKey(),
  date: text("date").notNull().unique(), // YYYY-MM-DD format
  wins: integer("wins").notNull().default(0),
  losses: integer("losses").notNull().default(0),
  totalPredictions: integer("total_predictions").notNull().default(0),
  accuracy: decimal("accuracy", { precision: 5, scale: 2 }).notNull().default("0"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const hashes = pgTable("hashes", {
  id: serial("id").primaryKey(),
  hash: text("hash").notNull(),
  seed: text("seed").notNull(),
  roundId: text("round_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertPredictionSchema = createInsertSchema(predictions).omit({
  id: true,
  createdAt: true,
  resolvedAt: true,
});

export const insertStatisticsSchema = createInsertSchema(statistics).omit({
  id: true,
  updatedAt: true,
});

export const insertHashSchema = createInsertSchema(hashes).omit({
  id: true,
  createdAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = z.infer<typeof insertPredictionSchema>;

export type Statistics = typeof statistics.$inferSelect;
export type InsertStatistics = z.infer<typeof insertStatisticsSchema>;

export type Hash = typeof hashes.$inferSelect;
export type InsertHash = z.infer<typeof insertHashSchema>;
