import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { PredictionService } from "./services/prediction-service";
import { AviatorService } from "./services/aviator-service";

export async function registerRoutes(app: Express): Promise<Server> {
  const predictionService = new PredictionService(storage);
  const aviatorService = new AviatorService(storage);
  
  const httpServer = createServer(app);
  
  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Store active WebSocket connections
  const clients = new Set<WebSocket>();
  
  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('🔌 Client connected via WebSocket');
    
    ws.on('close', () => {
      clients.delete(ws);
      console.log('🔌 Client disconnected from WebSocket');
    });
  });
  
  // Broadcast function for real-time updates
  const broadcast = (data: any) => {
    const message = JSON.stringify(data);
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  };

  // Initialize services with broadcast callback
  await aviatorService.initialize(broadcast);

  // Get current predictions
  app.get("/api/predictions", async (req, res) => {
    try {
      const predictions = await storage.getPredictions(10);
      res.json(predictions.map(p => ({
        id: p.id.toString(),
        time: new Date(p.createdAt).toLocaleTimeString('pt-BR', { 
          hour: '2-digit', 
          minute: '2-digit' 
        }),
        multiplier: p.status !== 'pending' && p.actualMultiplier 
          ? `${p.actualMultiplier}x` 
          : `${p.multiplier}x`,
        confidence: p.confidence,
        status: p.status,
        hash: p.hash,
        createdAt: p.createdAt.toISOString(),
        actualMultiplier: p.actualMultiplier
      })));
    } catch (error) {
      console.error('Error fetching predictions:', error);
      res.status(500).json({ error: 'Failed to fetch predictions' });
    }
  });

  // Get statistics
  app.get("/api/statistics", async (req, res) => {
    try {
      const stats = await storage.getTodayStatistics();
      res.json({
        wins: stats.wins,
        losses: stats.losses,
        accuracy: Math.round(parseFloat(stats.accuracy.toString())),
        totalPredictions: stats.totalPredictions
      });
    } catch (error) {
      console.error('Error fetching statistics:', error);
      res.status(500).json({ error: 'Failed to fetch statistics' });
    }
  });

  // Get current hash for provably fair
  app.get("/api/current-hash", async (req, res) => {
    try {
      const currentHash = await storage.getCurrentHash();
      res.json({
        hash: currentHash ? currentHash.hash.substring(0, 12) + '...' : 'Gerando...'
      });
    } catch (error) {
      console.error('Error fetching current hash:', error);
      res.status(500).json({ error: 'Failed to fetch current hash' });
    }
  });

  // Generate new prediction (for testing)
  app.post("/api/predictions", async (req, res) => {
    try {
      const prediction = await predictionService.generatePrediction();
      res.json({
        id: prediction.id.toString(),
        time: new Date(prediction.createdAt).toLocaleTimeString('pt-BR', { 
          hour: '2-digit', 
          minute: '2-digit' 
        }),
        multiplier: `${prediction.multiplier}x`,
        confidence: prediction.confidence,
        status: prediction.status,
        hash: prediction.hash,
        createdAt: prediction.createdAt.toISOString()
      });
    } catch (error) {
      console.error('Error generating prediction:', error);
      res.status(500).json({ error: 'Failed to generate prediction' });
    }
  });

  return httpServer;
}
