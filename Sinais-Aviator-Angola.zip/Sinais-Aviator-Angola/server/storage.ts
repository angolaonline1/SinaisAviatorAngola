import { 
  users, predictions, statistics, hashes,
  type User, type InsertUser,
  type Prediction, type InsertPrediction,
  type Statistics, type InsertStatistics,
  type Hash, type InsertHash
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Prediction methods
  getPredictions(limit?: number): Promise<Prediction[]>;
  getPrediction(id: number): Promise<Prediction | undefined>;
  createPrediction(prediction: InsertPrediction): Promise<Prediction>;
  updatePrediction(id: number, updates: Partial<Prediction>): Promise<Prediction>;
  getPendingPredictions(): Promise<Prediction[]>;

  // Statistics methods
  getStatistics(date: string): Promise<Statistics | undefined>;
  createOrUpdateStatistics(stats: InsertStatistics): Promise<Statistics>;
  getTodayStatistics(): Promise<Statistics>;

  // Hash methods
  getCurrentHash(): Promise<Hash | undefined>;
  createHash(hash: InsertHash): Promise<Hash>;
  getHashes(limit?: number): Promise<Hash[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private predictions: Map<number, Prediction>;
  private statistics: Map<string, Statistics>;
  private hashes: Map<number, Hash>;
  private currentUserId: number;
  private currentPredictionId: number;
  private currentStatisticsId: number;
  private currentHashId: number;

  constructor() {
    this.users = new Map();
    this.predictions = new Map();
    this.statistics = new Map();
    this.hashes = new Map();
    this.currentUserId = 1;
    this.currentPredictionId = 1;
    this.currentStatisticsId = 1;
    this.currentHashId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Prediction methods
  async getPredictions(limit: number = 10): Promise<Prediction[]> {
    const allPredictions = Array.from(this.predictions.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return allPredictions.slice(0, limit);
  }

  async getPrediction(id: number): Promise<Prediction | undefined> {
    return this.predictions.get(id);
  }

  async createPrediction(insertPrediction: InsertPrediction): Promise<Prediction> {
    const id = this.currentPredictionId++;
    const prediction: Prediction = {
      ...insertPrediction,
      id,
      createdAt: new Date(),
      resolvedAt: null,
      actualMultiplier: null
    };
    this.predictions.set(id, prediction);
    return prediction;
  }

  async updatePrediction(id: number, updates: Partial<Prediction>): Promise<Prediction> {
    const existing = this.predictions.get(id);
    if (!existing) {
      throw new Error(`Prediction with id ${id} not found`);
    }
    const updated = { ...existing, ...updates };
    this.predictions.set(id, updated);
    return updated;
  }

  async getPendingPredictions(): Promise<Prediction[]> {
    return Array.from(this.predictions.values())
      .filter(p => p.status === 'pending')
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  // Statistics methods
  async getStatistics(date: string): Promise<Statistics | undefined> {
    return this.statistics.get(date);
  }

  async createOrUpdateStatistics(stats: InsertStatistics): Promise<Statistics> {
    const existing = this.statistics.get(stats.date);
    if (existing) {
      const updated: Statistics = {
        ...existing,
        ...stats,
        updatedAt: new Date()
      };
      this.statistics.set(stats.date, updated);
      return updated;
    } else {
      const id = this.currentStatisticsId++;
      const newStats: Statistics = {
        ...stats,
        id,
        updatedAt: new Date()
      };
      this.statistics.set(stats.date, newStats);
      return newStats;
    }
  }

  async getTodayStatistics(): Promise<Statistics> {
    const today = new Date().toISOString().split('T')[0];
    const existing = await this.getStatistics(today);
    if (existing) {
      return existing;
    }
    // Create empty statistics for today
    return this.createOrUpdateStatistics({
      date: today,
      wins: 0,
      losses: 0,
      totalPredictions: 0,
      accuracy: "0"
    });
  }

  // Hash methods
  async getCurrentHash(): Promise<Hash | undefined> {
    const allHashes = Array.from(this.hashes.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return allHashes[0];
  }

  async createHash(insertHash: InsertHash): Promise<Hash> {
    const id = this.currentHashId++;
    const hash: Hash = {
      ...insertHash,
      id,
      createdAt: new Date()
    };
    this.hashes.set(id, hash);
    return hash;
  }

  async getHashes(limit: number = 10): Promise<Hash[]> {
    const allHashes = Array.from(this.hashes.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return allHashes.slice(0, limit);
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Prediction methods
  async getPredictions(limit: number = 10): Promise<Prediction[]> {
    return await db
      .select()
      .from(predictions)
      .orderBy(desc(predictions.createdAt))
      .limit(limit);
  }

  async getPrediction(id: number): Promise<Prediction | undefined> {
    const [prediction] = await db.select().from(predictions).where(eq(predictions.id, id));
    return prediction || undefined;
  }

  async createPrediction(insertPrediction: InsertPrediction): Promise<Prediction> {
    const [prediction] = await db
      .insert(predictions)
      .values(insertPrediction)
      .returning();
    return prediction;
  }

  async updatePrediction(id: number, updates: Partial<Prediction>): Promise<Prediction> {
    const [prediction] = await db
      .update(predictions)
      .set(updates)
      .where(eq(predictions.id, id))
      .returning();
    
    if (!prediction) {
      throw new Error(`Prediction with id ${id} not found`);
    }
    return prediction;
  }

  async getPendingPredictions(): Promise<Prediction[]> {
    return await db
      .select()
      .from(predictions)
      .where(eq(predictions.status, 'pending'))
      .orderBy(desc(predictions.createdAt));
  }

  // Statistics methods
  async getStatistics(date: string): Promise<Statistics | undefined> {
    const [stats] = await db.select().from(statistics).where(eq(statistics.date, date));
    return stats || undefined;
  }

  async createOrUpdateStatistics(stats: InsertStatistics): Promise<Statistics> {
    const existing = await this.getStatistics(stats.date);
    
    if (existing) {
      const [updated] = await db
        .update(statistics)
        .set({ ...stats, updatedAt: new Date() })
        .where(eq(statistics.date, stats.date))
        .returning();
      return updated;
    } else {
      const [newStats] = await db
        .insert(statistics)
        .values(stats)
        .returning();
      return newStats;
    }
  }

  async getTodayStatistics(): Promise<Statistics> {
    const today = new Date().toISOString().split('T')[0];
    const existing = await this.getStatistics(today);
    
    if (existing) {
      return existing;
    }
    
    // Create empty statistics for today
    return this.createOrUpdateStatistics({
      date: today,
      wins: 0,
      losses: 0,
      totalPredictions: 0,
      accuracy: "0"
    });
  }

  // Hash methods
  async getCurrentHash(): Promise<Hash | undefined> {
    const [hash] = await db
      .select()
      .from(hashes)
      .orderBy(desc(hashes.createdAt))
      .limit(1);
    return hash || undefined;
  }

  async createHash(insertHash: InsertHash): Promise<Hash> {
    const [hash] = await db
      .insert(hashes)
      .values(insertHash)
      .returning();
    return hash;
  }

  async getHashes(limit: number = 10): Promise<Hash[]> {
    return await db
      .select()
      .from(hashes)
      .orderBy(desc(hashes.createdAt))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();
