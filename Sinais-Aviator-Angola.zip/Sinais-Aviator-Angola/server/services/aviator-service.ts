import { IStorage } from "../storage";
import { PredictionService } from "./prediction-service";
import crypto from "crypto";

export class AviatorService {
  private predictionService: PredictionService;
  private isInitialized = false;
  private predictionInterval?: NodeJS.Timeout;
  private resolutionInterval?: NodeJS.Timeout;
  private broadcast?: (data: any) => void;

  constructor(private storage: IStorage) {
    this.predictionService = new PredictionService(storage);
  }

  async initialize(broadcastFn?: (data: any) => void) {
    if (this.isInitialized) return;

    this.broadcast = broadcastFn;
    console.log('🚀 Aviator Service: Initializing...');

    // Generate initial hash
    await this.generateNewHash();

    // Start prediction generation every 45 seconds
    this.predictionInterval = setInterval(async () => {
      try {
        const prediction = await this.predictionService.generatePrediction();
        console.log('📊 New prediction generated');
        
        // Broadcast new prediction to all connected clients
        if (this.broadcast) {
          this.broadcast({
            type: 'NEW_PREDICTION',
            data: {
              id: prediction.id.toString(),
              time: new Date(prediction.createdAt).toLocaleTimeString('pt-BR', { 
                hour: '2-digit', 
                minute: '2-digit' 
              }),
              multiplier: `${prediction.multiplier}x`,
              confidence: prediction.confidence,
              status: prediction.status,
              hash: prediction.hash,
              createdAt: prediction.createdAt.toISOString()
            }
          });
        }
      } catch (error) {
        console.error('Error generating prediction:', error);
      }
    }, 45000);

    // Start prediction resolution with realistic flight simulation
    this.resolutionInterval = setInterval(async () => {
      try {
        await this.resolvePendingPredictionsWithDelay();
      } catch (error) {
        console.error('Error resolving predictions:', error);
      }
    }, 5000); // Check every 5 seconds for more realistic timing

    this.isInitialized = true;
    console.log('✅ Aviator Service: Initialized successfully');
  }

  private async generateNewHash(): Promise<void> {
    const seed = this.generateSeed();
    const roundId = Date.now().toString();
    const input = `${seed}-${roundId}`;
    
    const hash = crypto.createHash('sha256').update(input).digest('hex');
    
    await this.storage.createHash({
      hash,
      seed,
      roundId
    });
  }

  private generateSeed(): string {
    return crypto.randomBytes(16).toString('hex');
  }

  private async resolvePendingPredictionsWithDelay(): Promise<void> {
    const pendingPredictions = await this.storage.getPendingPredictions();
    
    for (const prediction of pendingPredictions) {
      const timeSinceCreated = Date.now() - new Date(prediction.createdAt).getTime();
      const predictedMultiplier = parseFloat(prediction.multiplier);
      
      // Calculate realistic flight time based on multiplier
      // Lower multipliers = shorter flights, higher multipliers = longer flights
      const flightDuration = this.calculateFlightDuration(predictedMultiplier);
      
      // Only resolve if enough time has passed to simulate the flight
      if (timeSinceCreated >= flightDuration) {
        // Determine if the prediction wins based on realistic crash simulation
        const { isWin, actualMultiplier } = this.simulateRealisticFlight(predictedMultiplier);
        
        const status = isWin ? 'win' : 'loss';
        
        const updatedPrediction = await this.storage.updatePrediction(prediction.id, {
          status,
          actualMultiplier: actualMultiplier.toString(),
          resolvedAt: new Date()
        });

        // Update statistics
        await this.updateStatistics(status);
        
        console.log(`🎯 Prediction ${prediction.id} resolved: ${status} (${actualMultiplier}x) after ${Math.round(timeSinceCreated/1000)}s flight`);
        
        // Broadcast prediction result to all connected clients
        if (this.broadcast) {
          this.broadcast({
            type: 'PREDICTION_RESOLVED',
            data: {
              id: updatedPrediction.id.toString(),
              status,
              actualMultiplier,
              result: isWin ? '✅' : '❌'
            }
          });
        }
      }
    }
  }

  private calculateFlightDuration(predictedMultiplier: number): number {
    // Base flight time: 10 seconds minimum
    // Add time based on predicted multiplier (higher multiplier = longer potential flight)
    const baseTime = 10000; // 10 seconds
    const additionalTime = Math.min(predictedMultiplier * 2000, 30000); // Max 30 seconds additional
    return baseTime + additionalTime;
  }

  private simulateRealisticFlight(predictedMultiplier: number): { isWin: boolean, actualMultiplier: number } {
    // Simulate a realistic flight pattern
    // Higher multipliers are riskier but possible
    const riskFactor = Math.max(0.1, 1 - (predictedMultiplier - 1) * 0.15);
    const isWin = Math.random() < riskFactor;
    
    let actualMultiplier: number;
    
    if (isWin) {
      // For wins, plane flew past the predicted multiplier
      const variance = Math.random() * 0.3 + 0.1; // 10-40% higher
      actualMultiplier = predictedMultiplier * (1 + variance);
    } else {
      // For losses, plane crashed before reaching predicted multiplier
      const crashPoint = Math.random() * 0.8 + 0.1; // Crash between 10-90% of predicted
      actualMultiplier = predictedMultiplier * crashPoint;
    }
    
    return {
      isWin,
      actualMultiplier: Math.round(actualMultiplier * 100) / 100
    };
  }



  private async updateStatistics(result: 'win' | 'loss'): Promise<void> {
    const today = new Date().toISOString().split('T')[0];
    const currentStats = await this.storage.getTodayStatistics();
    
    const newWins = result === 'win' ? currentStats.wins + 1 : currentStats.wins;
    const newLosses = result === 'loss' ? currentStats.losses + 1 : currentStats.losses;
    const newTotal = newWins + newLosses;
    const newAccuracy = newTotal > 0 ? Math.round((newWins / newTotal) * 100) : 0;

    await this.storage.createOrUpdateStatistics({
      date: today,
      wins: newWins,
      losses: newLosses,
      totalPredictions: newTotal,
      accuracy: newAccuracy.toString()
    });
  }

  destroy() {
    if (this.predictionInterval) {
      clearInterval(this.predictionInterval);
    }
    if (this.resolutionInterval) {
      clearInterval(this.resolutionInterval);
    }
    this.isInitialized = false;
    console.log('🛑 Aviator Service: Destroyed');
  }
}
