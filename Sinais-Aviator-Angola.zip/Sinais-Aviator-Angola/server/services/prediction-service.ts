import { IStorage } from "../storage";
import crypto from "crypto";

export class PredictionService {
  constructor(private storage: IStorage) {}

  async generatePrediction() {
    // Generate provably fair hash
    const seed = this.generateSeed();
    const roundId = Date.now().toString();
    const hash = await this.generateHash(seed, roundId);

    // Use hash to determine multiplier and confidence
    const { multiplier, confidence } = this.calculatePredictionFromHash(hash);

    // Create prediction
    const prediction = await this.storage.createPrediction({
      multiplier: multiplier.toString(),
      confidence,
      hash,
      status: 'pending'
    });

    // Store the hash for transparency
    await this.storage.createHash({
      hash,
      seed,
      roundId
    });

    return prediction;
  }

  private generateSeed(): string {
    return crypto.randomBytes(16).toString('hex');
  }

  private async generateHash(seed: string, roundId: string): Promise<string> {
    const input = `${seed}-${roundId}`;
    return crypto.createHash('sha256').update(input).digest('hex');
  }

  private calculatePredictionFromHash(hash: string): { multiplier: number; confidence: number } {
    // Use first 8 characters of hash for calculations
    const hashSegment = hash.substring(0, 8);
    const hashNum = parseInt(hashSegment, 16);

    // Calculate multiplier (1.2x to 10x range)
    const multiplierBase = (hashNum % 880) / 100 + 1.2; // 1.2 to 10.0
    const multiplier = Math.round(multiplierBase * 100) / 100;

    // Calculate confidence based on multiplier (lower multipliers = higher confidence)
    let confidence: number;
    if (multiplier <= 2.0) {
      confidence = Math.floor(Math.random() * 15) + 85; // 85-99%
    } else if (multiplier <= 4.0) {
      confidence = Math.floor(Math.random() * 10) + 75; // 75-84%
    } else {
      confidence = Math.floor(Math.random() * 15) + 60; // 60-74%
    }

    return { multiplier, confidence };
  }

  async resolveStatistics() {
    const today = new Date().toISOString().split('T')[0];
    return await this.storage.getTodayStatistics();
  }
}
