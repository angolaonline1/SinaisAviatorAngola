interface OfflineIndicatorProps {
  show: boolean;
}

export default function OfflineIndicator({ show }: OfflineIndicatorProps) {
  if (!show) return null;

  return (
    <div 
      className="fixed bottom-4 left-4 right-4 p-3 rounded-xl text-white text-center font-semibold z-30 animate-slideInUp"
      style={{
        background: 'linear-gradient(135deg, var(--loss-red), #b91c1c)'
      }}
    >
      <i className="fas fa-wifi-slash mr-2" />
      Sem conexão com a internet - Reconectando...
    </div>
  );
}
