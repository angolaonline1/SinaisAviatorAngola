interface Statistics {
  wins: number;
  losses: number;
  accuracy: number;
  totalPredictions: number;
}

interface StatisticsPanelProps {
  statistics: Statistics;
}

export default function StatisticsPanel({ statistics }: StatisticsPanelProps) {
  return (
    <div 
      className="relative p-6 rounded-2xl border mb-8"
      style={{
        background: 'linear-gradient(135deg, var(--card), var(--muted))',
        borderColor: 'var(--border)'
      }}
    >
      {/* Top Border Gradient */}
      <div 
        className="absolute top-0 left-0 right-0 h-1 rounded-t-2xl"
        style={{
          background: 'linear-gradient(90deg, var(--angola-red), var(--angola-yellow), var(--aviation-blue))'
        }}
      />
      
      <h3 className="text-2xl font-extrabold text-center mb-5" style={{ color: 'var(--aviation-blue)' }}>
        <i className="fas fa-chart-bar mr-2" />
        Estatísticas de Hoje
      </h3>
      
      <div className="grid grid-cols-3 gap-5 text-center">
        <StatisticItem
          value={statistics.wins}
          label="Acertos"
          color="var(--win-green)"
          icon="fas fa-check"
        />
        <StatisticItem
          value={statistics.losses}
          label="Erros"
          color="var(--loss-red)"
          icon="fas fa-times"
        />
        <StatisticItem
          value={`${statistics.accuracy}%`}
          label="Precisão"
          color="var(--angola-yellow)"
          icon="fas fa-target"
        />
      </div>
    </div>
  );
}

interface StatisticItemProps {
  value: number | string;
  label: string;
  color: string;
  icon: string;
}

function StatisticItem({ value, label, color, icon }: StatisticItemProps) {
  return (
    <div 
      className="p-4 rounded-xl border transition-all duration-300 hover:transform hover:-translate-y-1"
      style={{
        background: 'rgba(59, 130, 246, 0.05)',
        borderColor: 'rgba(59, 130, 246, 0.1)'
      }}
    >
      <div className="text-3xl font-black mb-1" style={{ color }}>
        {value}
      </div>
      <div className="text-sm font-medium" style={{ color: 'var(--muted-foreground)' }}>
        <i className={`${icon} mr-1`} />
        {label}
      </div>
    </div>
  );
}
