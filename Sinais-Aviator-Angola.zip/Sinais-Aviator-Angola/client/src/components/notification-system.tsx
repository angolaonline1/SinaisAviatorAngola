import { useEffect } from "react";

interface Notification {
  id: string;
  type: 'info' | 'win' | 'loss';
  message: string;
  timestamp: number;
}

interface NotificationSystemProps {
  notifications: Notification[];
}

export default function NotificationSystem({ notifications }: NotificationSystemProps) {
  return (
    <div className="fixed top-20 right-4 z-40 space-y-3">
      {notifications.map(notification => (
        <NotificationItem key={notification.id} notification={notification} />
      ))}
    </div>
  );
}

interface NotificationItemProps {
  notification: Notification;
}

function NotificationItem({ notification }: NotificationItemProps) {
  const getBackgroundGradient = () => {
    switch (notification.type) {
      case 'win':
        return 'linear-gradient(135deg, var(--win-green), #047857)';
      case 'loss':
        return 'linear-gradient(135deg, var(--loss-red), #b91c1c)';
      default:
        return 'linear-gradient(135deg, var(--aviation-blue), #1e40af)';
    }
  };

  const getIcon = () => {
    switch (notification.type) {
      case 'win':
        return 'fas fa-check-circle';
      case 'loss':
        return 'fas fa-times-circle';
      default:
        return 'fas fa-info-circle';
    }
  };

  return (
    <div 
      className="max-w-80 p-4 rounded-xl text-white animate-slideInRight"
      style={{
        background: getBackgroundGradient(),
        boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
        backdropFilter: 'blur(10px)',
        border: '1px solid rgba(255,255,255,0.1)'
      }}
    >
      <div className="flex items-center gap-2">
        <i className={`${getIcon()} text-sm`} />
        <span className="text-sm font-medium">{notification.message}</span>
      </div>
    </div>
  );
}
