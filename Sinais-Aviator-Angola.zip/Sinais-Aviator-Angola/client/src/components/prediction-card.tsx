interface Prediction {
  id: string;
  time: string;
  multiplier: string;
  confidence: number;
  status: 'pending' | 'win' | 'loss';
  hash: string;
  createdAt: string;
  actualMultiplier?: string;
}

interface PredictionCardProps {
  prediction: Prediction;
  isCurrent: boolean;
}

export default function PredictionCard({ prediction, isCurrent }: PredictionCardProps) {
  const getStatusIcon = () => {
    switch (prediction.status) {
      case 'win': return '✅';
      case 'loss': return '❌';
      default: return '⏳';
    }
  };

  const getStatusText = () => {
    switch (prediction.status) {
      case 'win': return 'ACERTOU';
      case 'loss': return 'ERROU';
      default: return 'PENDENTE';
    }
  };

  const getStatusClass = () => {
    switch (prediction.status) {
      case 'win': return 'win';
      case 'loss': return 'loss';
      default: return 'pending';
    }
  };

  return (
    <div 
      className={`relative overflow-hidden p-5 rounded-2xl border transition-all duration-300 hover:transform hover:-translate-y-1 animate-fadeInUp ${isCurrent ? 'current' : ''}`}
      style={{
        background: 'linear-gradient(135deg, var(--card), var(--muted))',
        borderColor: isCurrent ? 'var(--angola-yellow)' : 'var(--border)',
        boxShadow: isCurrent ? '0 0 30px rgba(234, 179, 8, 0.3)' : 'none'
      }}
    >
      {/* Current Round Badge */}
      {isCurrent && (
        <div 
          className="absolute top-0 right-0 px-3 py-1 text-xs font-extrabold text-black rounded-bl-lg"
          style={{ background: 'var(--angola-yellow)' }}
        >
          RODADA ATUAL
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 font-semibold text-lg">
          <i className="fas fa-clock text-xl" style={{ color: 'var(--aviation-blue)' }} />
          <span>{prediction.time}</span>
        </div>
        <span 
          className={`prediction-status ${getStatusClass()} px-3 py-1 rounded-lg text-sm font-extrabold`}
          style={{
            color: prediction.status === 'win' ? 'var(--win-green)' : 
                   prediction.status === 'loss' ? 'var(--loss-red)' : 'var(--angola-yellow)',
            background: prediction.status === 'win' ? 'rgba(16, 185, 129, 0.1)' : 
                        prediction.status === 'loss' ? 'rgba(239, 68, 68, 0.1)' : 'rgba(234, 179, 8, 0.1)',
            border: `1px solid ${prediction.status === 'win' ? 'var(--win-green)' : 
                                 prediction.status === 'loss' ? 'var(--loss-red)' : 'var(--angola-yellow)'}`
          }}
        >
          {getStatusIcon()} {getStatusText()}
        </span>
      </div>

      {/* Body */}
      <div className="flex items-center justify-between">
        <div>
          <div 
            className="text-3xl font-black bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent"
          >
            {prediction.multiplier}
          </div>
          <div className="text-sm mt-1" style={{ color: 'var(--muted-foreground)' }}>
            Multiplicador {isCurrent ? 'Previsto' : ''}
          </div>
        </div>
        <div className="text-right">
          <div className="text-xl font-bold" style={{ color: 'var(--aviation-blue)' }}>
            {prediction.confidence}%
          </div>
          <div className="text-xs mt-1" style={{ color: 'var(--muted-foreground)' }}>
            Confiança
          </div>
        </div>
      </div>
    </div>
  );
}
