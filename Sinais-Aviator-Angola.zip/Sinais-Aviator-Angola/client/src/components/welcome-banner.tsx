interface WelcomeBannerProps {
  show: boolean;
}

export default function WelcomeBanner({ show }: WelcomeBannerProps) {
  if (!show) return null;

  return (
    <div 
      className={`fixed top-0 left-0 right-0 z-50 p-4 text-center text-black font-bold animate-slideDown ${!show ? 'hidden' : ''}`}
      style={{
        background: 'linear-gradient(45deg, var(--angola-red), var(--angola-yellow), var(--angola-red))',
        backgroundSize: '200% 200%',
        boxShadow: '0 4px 20px rgba(0,0,0,0.3)'
      }}
    >
      <div className="flex items-center justify-center gap-2">
        <span>✈️</span>
        <span>Seja Bem Vindo ao Sinais Aviator Angola 🇦🇴</span>
        <span>✈️</span>
      </div>
    </div>
  );
}
