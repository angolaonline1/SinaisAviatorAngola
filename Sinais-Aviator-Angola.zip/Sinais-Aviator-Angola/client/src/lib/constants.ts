export const AFFILIATE_URL = "https://bantubet.co.ao/affiliates/?btag=1316876_l367292";

export const MULTIPLIER_RANGES = {
  LOW: { min: 1.2, max: 2.0 },
  MEDIUM: { min: 2.0, max: 4.0 },
  HIGH: { min: 4.0, max: 10.0 }
};

export const CONFIDENCE_THRESHOLDS = {
  LOW: 70,
  MEDIUM: 80,
  HIGH: 90
};

export const UPDATE_INTERVALS = {
  PREDICTIONS: 15000, // 15 seconds
  STATISTICS: 30000, // 30 seconds
  HASH: 10000 // 10 seconds
};
