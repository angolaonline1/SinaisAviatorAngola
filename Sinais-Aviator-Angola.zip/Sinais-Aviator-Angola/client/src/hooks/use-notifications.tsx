import { useState, useCallback } from 'react';

interface Notification {
  id: string;
  type: 'info' | 'win' | 'loss';
  message: string;
  timestamp: number;
}

export function useNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const showNotification = useCallback((type: 'info' | 'win' | 'loss', message: string) => {
    const notification: Notification = {
      id: Date.now().toString(),
      type,
      message,
      timestamp: Date.now()
    };

    setNotifications(prev => [notification, ...prev]);

    // Auto-hide after 9 seconds
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== notification.id));
    }, 9000);
  }, []);

  return { notifications, showNotification };
}
