import { useEffect, useRef, useState } from 'react';

interface WebSocketMessage {
  type: 'NEW_PREDICTION' | 'PREDICTION_RESOLVED';
  data: any;
}

export function useWebSocket(showNotification?: (type: 'info' | 'win' | 'loss', message: string) => void) {
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const [lastPrediction, setLastPrediction] = useState<any>(null);
  const [predictions, setPredictions] = useState<any[]>([]);

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const connect = () => {
      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          setIsConnected(true);
          console.log('🔌 WebSocket connected');
        };

        ws.onmessage = (event) => {
          try {
            const message: WebSocketMessage = JSON.parse(event.data);
            
            switch (message.type) {
              case 'NEW_PREDICTION':
                const newPrediction = message.data;
                setLastPrediction(newPrediction);
                setPredictions(prev => [newPrediction, ...prev.slice(0, 9)]);
                
                // Show notification for new prediction - exact match with screen display
                if (showNotification) {
                  showNotification('info', `🆕 Novo sinal: ${newPrediction.multiplier} (${newPrediction.confidence}% confiança)`);
                }
                
                // Browser push notification if permission granted
                if ('Notification' in window && Notification.permission === 'granted') {
                  new Notification('🎯 Novo Sinal Aviator', {
                    body: `Multiplicador: ${newPrediction.multiplier} • Confiança: ${newPrediction.confidence}%`,
                    icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">✈️</text></svg>',
                    tag: 'aviator-prediction'
                  });
                }
                break;

              case 'PREDICTION_RESOLVED':
                const resolvedData = message.data;
                
                // Update predictions list with actualMultiplier
                setPredictions(prev => prev.map(p => 
                  p.id === resolvedData.id 
                    ? { 
                        ...p, 
                        status: resolvedData.status,
                        actualMultiplier: resolvedData.actualMultiplier,
                        multiplier: `${resolvedData.actualMultiplier}x` // Update display to show actual result
                      }
                    : p
                ));
                
                // Show result notification matching the screen display
                const isWin = resolvedData.status === 'win';
                const message_text = isWin 
                  ? `✅ ACERTOU! Resultado: ${resolvedData.actualMultiplier}x` 
                  : `❌ ERROU! Resultado: ${resolvedData.actualMultiplier}x`;
                
                if (showNotification) {
                  showNotification(isWin ? 'win' : 'loss', message_text);
                }
                
                // Browser push notification for results
                if ('Notification' in window && Notification.permission === 'granted') {
                  new Notification(isWin ? '🎉 Acertou!' : '❌ Errou!', {
                    body: message_text,
                    icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">✈️</text></svg>',
                    tag: 'aviator-result'
                  });
                }
                break;
            }
          } catch (error) {
            console.error('Error parsing WebSocket message:', error);
          }
        };

        ws.onclose = () => {
          setIsConnected(false);
          console.log('🔌 WebSocket disconnected');
          
          // Attempt to reconnect after 3 seconds
          setTimeout(connect, 3000);
        };

        ws.onerror = (error) => {
          console.error('WebSocket error:', error);
          setIsConnected(false);
        };

      } catch (error) {
        console.error('Failed to create WebSocket connection:', error);
        setTimeout(connect, 3000);
      }
    };

    connect();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [showNotification]);

  return {
    isConnected,
    lastPrediction,
    predictions,
    setPredictions
  };
}