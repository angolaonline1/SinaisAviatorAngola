import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import WelcomeBanner from "@/components/welcome-banner";
import NotificationSystem from "@/components/notification-system";
import PredictionCard from "@/components/prediction-card";
import StatisticsPanel from "@/components/statistics-panel";
import OfflineIndicator from "@/components/offline-indicator";
import { useOnlineStatus } from "@/hooks/use-online-status";
import { useNotifications } from "@/hooks/use-notifications";
import { useWebSocket } from "@/hooks/use-websocket";
import { AFFILIATE_URL } from "@/lib/constants";

interface Prediction {
  id: string;
  time: string;
  multiplier: string;
  confidence: number;
  status: 'pending' | 'win' | 'loss';
  hash: string;
  createdAt: string;
  actualMultiplier?: string;
}

interface Statistics {
  wins: number;
  losses: number;
  accuracy: number;
  totalPredictions: number;
}

export default function Home() {
  const [showWelcome, setShowWelcome] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const isOnline = useOnlineStatus();
  const { showNotification, notifications } = useNotifications();
  const { isConnected: wsConnected, predictions: wsPredictions, setPredictions } = useWebSocket(showNotification);

  // Fallback to API polling when WebSocket is not connected
  const { data: apiPredictions = [], isLoading: predictionsLoading } = useQuery<Prediction[]>({
    queryKey: ['/api/predictions'],
    refetchInterval: wsConnected ? false : 15000, // Only poll when WebSocket is disconnected
  });

  // Fetch statistics (still use polling for statistics)
  const { data: statistics } = useQuery<Statistics>({
    queryKey: ['/api/statistics'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch current hash for provably fair
  const { data: currentHash } = useQuery<{ hash: string }>({
    queryKey: ['/api/current-hash'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Use WebSocket predictions if available, otherwise fallback to API
  const predictions = wsConnected && wsPredictions.length > 0 ? wsPredictions : apiPredictions;

  // Hide welcome banner after 5 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowWelcome(false);
    }, 5000);
    return () => clearTimeout(timer);
  }, []);

  // Update last update time when predictions change
  useEffect(() => {
    if (predictions.length > 0) {
      setLastUpdate(new Date());
    }
  }, [predictions]);

  // Initialize predictions from API if WebSocket is not connected
  useEffect(() => {
    if (!wsConnected && apiPredictions.length > 0) {
      setPredictions(apiPredictions);
    }
  }, [wsConnected, apiPredictions, setPredictions]);

  // Show initial notification
  useEffect(() => {
    const timer = setTimeout(() => {
      showNotification("info", "Sistema iniciado! Pronto para receber sinais 🎯");
    }, 2000);
    return () => clearTimeout(timer);
  }, [showNotification]);

  // Show offline/online notifications
  useEffect(() => {
    if (!isOnline) {
      showNotification("loss", "❌ Sem conexão com a internet - Reconectando...");
    } else {
      // Only show online notification if we were previously offline
      const wasOffline = localStorage.getItem('was-offline');
      if (wasOffline) {
        showNotification("win", "✅ Conexão restaurada! Sinais ativos novamente.");
        localStorage.removeItem('was-offline');
      }
    }
    
    if (!isOnline) {
      localStorage.setItem('was-offline', 'true');
    }
  }, [isOnline, showNotification]);

  const openAffiliate = () => {
    showNotification('info', '🎁 Redirecionando para cadastro com bônus...');
    window.open(AFFILIATE_URL, "_blank");
  };

  const enableNotifications = () => {
    if ('Notification' in window) {
      Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
          showNotification('win', '🔔 Notificações ativadas com sucesso!');
        } else {
          showNotification('info', 'ℹ️ Permita notificações nas configurações do navegador');
        }
      });
    } else {
      showNotification('info', 'ℹ️ Notificações não suportadas neste navegador');
    }
  };

  const currentPrediction = predictions.find(p => p.status === 'pending');
  const recentPredictions = predictions.filter(p => p.status !== 'pending').slice(0, 3);

  return (
    <div className="min-h-screen">
      <WelcomeBanner show={showWelcome} />
      <NotificationSystem notifications={notifications} />
      <OfflineIndicator show={!isOnline} />

      {/* Header */}
      <header className="relative overflow-hidden" style={{
        background: 'linear-gradient(135deg, var(--card) 0%, var(--muted) 100%)',
        borderBottom: '2px solid var(--border)',
        paddingTop: showWelcome ? '90px' : '24px',
        paddingBottom: '24px',
        paddingLeft: '16px',
        paddingRight: '16px'
      }}>
        {/* Grid Pattern Overlay */}
        <div className="absolute inset-0 opacity-10 z-0" style={{
          backgroundImage: `url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><defs><pattern id='grid' width='10' height='10' patternUnits='userSpaceOnUse'><path d='M 10 0 L 0 0 0 10' fill='none' stroke='%23334155' stroke-width='0.5' opacity='0.3'/></pattern></defs><rect width='100' height='100' fill='url(%23grid)'/></svg>")`,
        }} />
        
        <div className="max-w-md mx-auto relative z-10">
          {/* Header Title */}
          <div className="text-center mb-6">
            <div className="flex items-center justify-center gap-4 mb-3">
              <i className="fas fa-plane text-3xl animate-float" style={{ color: 'var(--aviation-blue)' }} />
              <h1 className="text-3xl font-extrabold bg-gradient-to-r from-blue-400 via-yellow-400 to-red-500 bg-clip-text text-transparent animate-gradientShift" style={{
                backgroundSize: '200% 200%'
              }}>
                Sinais Aviator
              </h1>
              <i className="fas fa-plane text-3xl animate-float scale-x-[-1]" style={{ 
                color: 'var(--aviation-blue)',
                animationDelay: '1.5s'
              }} />
            </div>
            <p className="text-lg font-medium" style={{ color: 'var(--muted-foreground)' }}>
              Prognósticos em tempo real • Angola 🇦🇴
            </p>
          </div>

          {/* Bonus Banner */}
          <div 
            className="relative overflow-hidden p-5 rounded-2xl mb-5 text-center animate-gradientShift"
            style={{
              background: 'linear-gradient(45deg, var(--angola-red), var(--angola-yellow), var(--accent-orange))',
              backgroundSize: '200% 200%',
              boxShadow: '0 8px 32px rgba(234, 179, 8, 0.3)',
              border: '2px solid rgba(255,255,255,0.2)'
            }}
          >
            {/* Shine Effect */}
            <div 
              className="absolute top-0 w-full h-full animate-shine"
              style={{
                left: '-100%',
                background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)'
              }}
            />
            
            <div className="text-xl font-extrabold text-black mb-2 text-shadow">
              🎁 Bônus de Boas-Vindas
            </div>
            <div className="text-2xl font-black text-black text-shadow">
              Até 300.000kz
            </div>
            <button 
              onClick={openAffiliate}
              className="mt-3 px-8 py-3 rounded-xl font-bold text-lg uppercase tracking-wide transition-all duration-300 hover:transform hover:-translate-y-1"
              style={{
                background: 'linear-gradient(135deg, #111827, #1f2937)',
                color: 'var(--angola-yellow)',
                border: '2px solid var(--angola-yellow)',
                letterSpacing: '0.5px'
              }}
            >
              <i className="fas fa-gift mr-2" />
              Obter Bônus
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto p-8">
        {/* Live Status */}
        <div 
          className="flex items-center justify-center gap-3 mb-8 p-4 rounded-2xl border"
          style={{
            background: 'linear-gradient(135deg, var(--card), var(--muted))',
            borderColor: 'var(--border)'
          }}
        >
          <div 
            className="w-4 h-4 rounded-full animate-pulse-custom"
            style={{
              background: wsConnected 
                ? 'radial-gradient(circle, var(--win-green), #047857)' 
                : 'radial-gradient(circle, var(--angola-yellow), #ca8a04)',
              boxShadow: wsConnected 
                ? '0 0 20px rgba(16, 185, 129, 0.5)' 
                : '0 0 20px rgba(234, 179, 8, 0.5)'
            }}
          />
          <span 
            className="text-lg font-bold" 
            style={{ 
              color: wsConnected ? 'var(--win-green)' : 'var(--angola-yellow)' 
            }}
          >
            <i className="fas fa-broadcast-tower mr-2" />
            {wsConnected ? 'Sistema Online • Sinais Ativos' : 'Reconectando • Aguarde'}
          </span>
        </div>

        {/* Predictions Section */}
        <div className="mb-10">
          <div className="flex items-center justify-between mb-5 px-1">
            <h2 
              className="text-2xl font-extrabold bg-gradient-to-r from-blue-400 to-yellow-400 bg-clip-text text-transparent"
            >
              <i className="fas fa-chart-line mr-2" />
              Prognósticos
            </h2>
            <span 
              className="text-sm px-3 py-1 rounded-lg border"
              style={{
                color: 'var(--muted-foreground)',
                background: 'var(--muted)',
                borderColor: 'var(--border)'
              }}
            >
              <i className="fas fa-clock mr-1" />
              {lastUpdate.toLocaleTimeString('pt-BR', { 
                hour: '2-digit', 
                minute: '2-digit' 
              })}
            </span>
          </div>

          {predictionsLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-24 rounded-2xl animate-pulse" style={{ background: 'var(--muted)' }} />
              ))}
            </div>
          ) : (
            <div className="space-y-6">
              {/* Current Active Prediction - Highlighted */}
              {currentPrediction && (
                <div className="relative">
                  {/* Special Current Prediction Header */}
                  <div 
                    className="text-center p-3 rounded-t-2xl border-2 animate-pulse-custom"
                    style={{
                      background: 'linear-gradient(135deg, var(--aviation-blue), var(--angola-yellow))',
                      borderColor: 'var(--aviation-blue)',
                      color: 'white'
                    }}
                  >
                    <div className="flex items-center justify-center gap-2 text-lg font-extrabold">
                      <i className="fas fa-bullseye animate-spin-slow" />
                      <span>PROGNÓSTICO ATUAL</span>
                      <i className="fas fa-bullseye animate-spin-slow" />
                    </div>
                  </div>
                  
                  {/* Enhanced Current Prediction Card */}
                  <div 
                    className="relative border-4 border-t-0 rounded-b-2xl p-6 animate-glow"
                    style={{
                      background: 'linear-gradient(135deg, var(--card), rgba(59, 130, 246, 0.1))',
                      borderColor: 'var(--aviation-blue)',
                      boxShadow: '0 0 30px rgba(59, 130, 246, 0.3)'
                    }}
                  >
                    {/* Pulse animation border */}
                    <div 
                      className="absolute inset-0 rounded-b-2xl animate-pulse-border"
                      style={{
                        background: 'linear-gradient(45deg, transparent, rgba(59, 130, 246, 0.2), transparent)',
                        backgroundSize: '200% 200%'
                      }}
                    />
                    
                    <div className="relative z-10">
                      <div className="text-center mb-4">
                        <div 
                          className="text-4xl font-black mb-2"
                          style={{ color: 'var(--aviation-blue)' }}
                        >
                          {currentPrediction.multiplier}
                        </div>
                        <div 
                          className="text-xl font-bold mb-2"
                          style={{ color: 'var(--angola-yellow)' }}
                        >
                          {currentPrediction.confidence}% Confiança
                        </div>
                        <div 
                          className="text-sm opacity-75"
                          style={{ color: 'var(--muted-foreground)' }}
                        >
                          <i className="fas fa-clock mr-1" />
                          Aguardando resultado do voo...
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-center gap-4 text-sm">
                        <span style={{ color: 'var(--muted-foreground)' }}>
                          <i className="fas fa-clock mr-1" />
                          {new Date(currentPrediction.createdAt).toLocaleTimeString('pt-BR', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </span>
                        <span 
                          className="px-3 py-1 rounded-lg text-xs font-bold animate-pulse"
                          style={{
                            background: 'var(--aviation-blue)',
                            color: 'white'
                          }}
                        >
                          <i className="fas fa-plane mr-1 animate-spin-slow" />
                          VOANDO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Recent Predictions - Smaller */}
              {recentPredictions.length > 0 && (
                <div>
                  <h3 
                    className="text-lg font-bold mb-3 text-center"
                    style={{ color: 'var(--muted-foreground)' }}
                  >
                    <i className="fas fa-history mr-2" />
                    Resultados Recentes
                  </h3>
                  <div className="space-y-3">
                    {recentPredictions.map(prediction => (
                      <PredictionCard 
                        key={prediction.id} 
                        prediction={prediction}
                        isCurrent={false}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Statistics */}
        {statistics && <StatisticsPanel statistics={statistics} />}

        {/* Call to Action Section */}
        <div className="mb-8 space-y-4">
          <button 
            onClick={openAffiliate}
            className="w-full p-5 rounded-2xl font-extrabold text-lg uppercase tracking-wide transition-all duration-300 hover:transform hover:-translate-y-1 relative overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, #2563eb, #dc2626, #ea580c)',
              backgroundSize: '200% 200%',
              color: 'white',
              boxShadow: '0 8px 32px rgba(37, 99, 235, 0.3)',
              letterSpacing: '0.5px'
            }}
          >
            {/* Shine Effect */}
            <div 
              className="absolute top-0 w-full h-full"
              style={{
                left: '-100%',
                background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent)',
                transition: 'left 0.5s'
              }}
            />
            <i className="fas fa-rocket mr-2" />
            Jogar Aviator Agora
          </button>
          
          <button 
            onClick={enableNotifications}
            className="w-full p-5 rounded-2xl font-extrabold text-lg uppercase tracking-wide transition-all duration-300 hover:transform hover:-translate-y-1 relative overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, #eab308, #dc2626, #ea580c)',
              backgroundSize: '200% 200%',
              color: '#111',
              boxShadow: '0 8px 32px rgba(234, 179, 8, 0.3)',
              letterSpacing: '0.5px'
            }}
          >
            <i className="fas fa-bell mr-2" />
            Ativar Notificações
          </button>
        </div>

        {/* Algorithm Transparency */}
        <div 
          className="relative p-6 rounded-2xl border mb-8"
          style={{
            background: 'linear-gradient(135deg, var(--card), var(--muted))',
            borderColor: 'var(--border)'
          }}
        >
          <div 
            className="absolute top-0 left-0 right-0 h-1 rounded-t-2xl"
            style={{
              background: 'linear-gradient(90deg, var(--angola-red), var(--angola-yellow), var(--aviation-blue))'
            }}
          />
          
          <h3 className="text-2xl font-extrabold text-center mb-5" style={{ color: 'var(--aviation-blue)' }}>
            <i className="fas fa-shield-alt mr-2" />
            Sistema Provably Fair
          </h3>
          
          <div className="text-center space-y-3" style={{ color: 'var(--muted-foreground)', lineHeight: '1.8' }}>
            <p>
              <i className="fas fa-lock mr-2" style={{ color: 'var(--win-green)' }} />
              Algoritmo SHA-256 para transparência total
            </p>
            <p>
              <i className="fas fa-database mr-2" style={{ color: 'var(--aviation-blue)' }} />
              Dados validados pela Bantubet Angola
            </p>
            <div 
              className="mt-4 p-3 rounded-lg font-mono text-xs"
              style={{ background: 'var(--muted)' }}
            >
              Hash Atual: <span style={{ color: 'var(--angola-yellow)' }}>
                {currentHash?.hash || 'Carregando...'}
              </span>
            </div>
          </div>
        </div>

        {/* Disclaimer */}
        <div 
          className="text-sm text-center mt-8 p-5 rounded-xl border"
          style={{
            color: 'var(--muted-foreground)',
            background: 'var(--muted)',
            borderColor: 'var(--border)',
            lineHeight: '1.6'
          }}
        >
          <p className="mb-2"><strong>⚠️ Aviso Legal:</strong></p>
          <p className="mb-2">Os sinais são baseados em análise algorítmica e não garantem ganhos. Apostas envolvem riscos financeiros.</p>
          <p className="mb-2">Jogue com responsabilidade e apenas com dinheiro que pode perder.</p>
          <p><strong>+18 anos</strong> • <strong>Licenciado em Angola</strong></p>
        </div>
      </main>
    </div>
  );
}
