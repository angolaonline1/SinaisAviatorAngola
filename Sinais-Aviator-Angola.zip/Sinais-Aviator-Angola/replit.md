# Aviator Signals Angola - Full Stack Application

## Overview

This is a full-stack web application that provides real-time Aviator game predictions and signals for users in Angola. The application features a modern dark-themed UI with Portuguese localization, real-time data updates, and a comprehensive prediction system with provably fair algorithms.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with clear separation between frontend, backend, and shared components:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom aviation-themed color palette
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM (DatabaseStorage implementation)
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: connect-pg-simple for PostgreSQL-backed sessions
- **Real-time Communication**: WebSocket server for live prediction updates

### Key Components

#### Database Schema
The application uses four main tables:
- **users**: User authentication and profile data
- **predictions**: Game predictions with multipliers, confidence levels, and outcomes
- **statistics**: Daily aggregated statistics for wins, losses, and accuracy
- **hashes**: Provably fair hash storage for transparency

#### Prediction System
- **PredictionService**: Generates predictions using SHA-256 hashing algorithms
- **AviatorService**: Orchestrates prediction generation and resolution cycles with WebSocket broadcasting
- **Storage Layer**: Abstracted storage interface with PostgreSQL DatabaseStorage implementation
- **Real-time Updates**: WebSocket connections for instant prediction updates and notifications

#### Real-time Features
- **Live Updates**: Predictions refresh every 15 seconds, statistics every 30 seconds
- **Notification System**: Custom notification system for win/loss alerts
- **Offline Detection**: Network status monitoring with user feedback

## Data Flow

1. **Prediction Generation**: AviatorService generates new predictions every 45 seconds using provably fair algorithms
2. **Hash Creation**: Each prediction includes a SHA-256 hash for transparency
3. **Real-time Updates**: Frontend polls API endpoints for fresh data
4. **Statistics Aggregation**: Daily statistics are calculated and stored
5. **Prediction Resolution**: Pending predictions are resolved every 20 seconds

## External Dependencies

### Frontend Dependencies
- **UI Components**: Extensive Radix UI component library for accessible primitives
- **Icons**: Font Awesome for iconography
- **Fonts**: Inter font family from Google Fonts
- **Animation**: CSS transitions and Tailwind animations

### Backend Dependencies
- **Database**: @neondatabase/serverless for PostgreSQL connectivity
- **ORM**: Drizzle ORM with Zod validation schemas
- **Cryptography**: Node.js built-in crypto module for hash generation
- **Session Storage**: PostgreSQL-backed session management

### Development Tools
- **Type Checking**: TypeScript with strict configuration
- **Development Server**: Vite with HMR and error overlay
- **Database Migrations**: Drizzle Kit for schema management
- **Build Process**: esbuild for server-side bundling

## Deployment Strategy

### Development
- Vite development server for frontend with HMR
- Express server with TypeScript compilation via tsx
- Environment variables for database configuration
- Replit-specific development tooling integration

### Production
- Frontend built to static assets via Vite
- Backend bundled with esbuild for Node.js deployment
- Database migrations managed through Drizzle Kit
- Environment-based configuration for different deployment targets

### Database Management
- PostgreSQL as primary database with Drizzle ORM
- Migration system for schema updates
- Connection pooling through Neon's serverless infrastructure

The application is designed for Portuguese-speaking users in Angola, with localized content, currency references (kz), and culturally relevant theming that incorporates Angola's national colors and aviation imagery.